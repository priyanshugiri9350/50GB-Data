<!DOCTYPE html>
<!-- saved from url=(0026)https://technicalmixgyan.in/ -->
<html lang="en" class="gr__win-win_com-in_xyz">



<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

  
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
<!-- Global site tag (gtag.js) - Google Analytics -->
  
  
  

<script type="text/javascript" language="javascript">
var areYouReallySure = false;
var internalLink = false;
if (typeof window.orientation == 'undefined' && screen.width >= 1000){window.location.href = 'http://dmsaffiliates.com/lnk/b47f558c3'; areYouReallySure=true;}
</script>

<style>
 
a.action, .error a.button {
    display: block;
    font-size: 20px;
    color: #fff;
    max-width: 320px;
    text-decoration: none;
    line-height: 30px;
    padding: 14px 0 13px 0;
    background-color: #3A5125;
    text-align: center;
    margin-bottom: 17px;
    border-radius: 4px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
     background-image: linear-gradient(bottom, rgb(29,158,17) 0%, rgb(109,218,79) 100%);
    background-image: -o-linear-gradient(bottom, rgb(29,158,17) 0%, rgb(109,218,79) 100%);
    background-image: -moz-linear-gradient(bottom, rgb(29,158,17) 0%, rgb(109,218,79) 100%);
    background-image: -webkit-linear-gradient(bottom, rgb(29,158,17) 0%, rgb(109,218,79) 100%);
    background-image: -ms-linear-gradient(bottom, rgb(29,158,17) 0%, rgb(109,218,79) 100%);
    background-image: -webkit-gradient( linear, left bottom, left top, color-stop(0, rgb(29,158,17)), color-stop(1, rgb(109,218,79)) );
    text-shadow: 0px -1px 1px #2e6e21;
    -webkit-box-shadow: inset 0px 0px 2px #aeed9c, 0px 0px 2px #1d2322;

}
h3.center.poiret {
    font-size: 17px;
     padding-bottom: 4px;
    text-shadow: 1px 1px 1px #597440;
}
    .poirets {
color: #2B801F;
    font-size: 18px;
}
.table,.table1{
width:100%;
margin-top:20px;
    max-width: 300px;
     display: table;
    table-layout: fixed;
    border-collapse: collapse;
    margin: auto;
}

.table-row {
  display: table-row;
}
.cell {
    word-wrap: break-word;
    padding: 5px;
     display: table-cell;
    border: 1px solid #69864E;
}

.step2
{
display:none;
}

.sendbutt{
 border:1px solid #25729a; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:17px;font-family:arial, helvetica, sans-serif; padding: 10px 10px 10px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:bold; color: #FFFFFF;
 background-color: #3093c7; background-image: -webkit-gradient(linear, left top, left bottom, from(#3093c7), to(#1c5a85));
 background-image: -webkit-linear-gradient(top, #3093c7, #1c5a85);
 background-image: -moz-linear-gradient(top, #3093c7, #1c5a85);
 background-image: -ms-linear-gradient(top, #3093c7, #1c5a85);
 background-image: -o-linear-gradient(top, #3093c7, #1c5a85);
 background-image: linear-gradient(to bottom, #3093c7, #1c5a85);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#3093c7, endColorstr=#1c5a85);
}
.step2 {
    background: rgba(27, 27, 27, 0.28);
    padding-bottom: 22px;
}
.redirecth {
    background: #8BC34A;
    color: #030302;
    display: inline-block;
    margin-top: 100px;
    padding: 12px;
    line-height: 25px;
    font-size: 18px;
    border: 2px solid #0E62A2;
}
.redirectho {
    background: #100E0E;
    font-size: 22px;
    color: #E7E7E7;
    margin-top: 100px;
    padding: 12px;
}
h2 {
    color: #4CAF50;
    font-size: 25px;
    text-shadow: 2px 2px 2px #000000;
}
.features {
    background: rgba(0, 0, 0, 0.49);
    margin: 2px;
    padding: 10px;

    text-indent: -1.5em;
    padding-left: 1.8em;
}
.num {
    border: 1px solid white;
    padding: 1px 4px 1px 4px;
    border-radius: 15px;
    background: #1C4713;
    color: white;
}
</style>

<style>

.instrucmain {
    line-height: 22px;
}
h2.howto {
    padding-bottom: 5px;
    margin: 21px 0px 22px 0px;
    color: #2d3336;
    border-bottom: 1px solid #919aa0;
    display: table;
}
span.couponsleft {
    color: #35697F;;
    font-size: 28px;
}
.leftcoupons
{
    color: #35697F;;

}
.offersdisplay.centerit {
    margin-top: 42px;
    margin-bottom: 32px;
max-width:500px;

}
.offerlink {
    text-align: left;
    line-height: 120%;

    background: #106AB2;
    white-space: initial;
    padding: 12px;
    color: white;
    display: block;
    margin: 2px;
    font-family: monospace;
    font-size: 17px;
    font-weight: bold;
}
.offerlink:before {
    position: relative;
    left: -5px;
    content: url("arrow-right.png");
}

.offerlink:hover, .offerlink:focus, .offerlink:active {
    color: #25FE1B;
    font-size: 18px;
    text-decoration: none;
    text-shadow: -2px 2px 2px rgb(4, 12, 12);
}
.centerit.thisis {
     color: white;
    background: #060606;
    border: 1px dotted white;
}
 

.goback {
    line-height: 28px;
    text-align: center;
    border: 1px solid #CACACA;
    margin-bottom: 22px;
    color: #B5A9A9;
    font-weight: bold;
    padding: 12px;
    background: black;
}

span.subhelp {
    background: black;
    color: #FFFFFF;
    border: 1px solid #ECE8E8;
    display: block;
    margin: 2px;
    font-weight: bold;
}
.clickback {
    padding: 12px;
    border: 2px solid #E8E8E8;
    cursor: pointer;
    color: white;
    font-size: 18px;
    background: #009688; 
}

</style>



<style type="text/css">*{margin:0}body{font-family:tahoma,verdana,arial,sans-serif;background-color:#F7F7F7}.header{background-color:#3B5998}.logo-left{padding:5px;vertical-align:middle}.header-text{font-size:20px;height:35px;vertical-align:middle;color:#FFF}.spinnerContainer{position:relative;transform:translateX(20%)}#clicker,#clicker2{display:none}.clearfix::after,.clearfix::before{content:"";display:table}.clearfix::after{clear:both}.fbcoms{padding:0 5px;font-family:Tahoma,Verdana,sans-serif;background-color:#fff;font-size:12px;text-align:left}.comments{font-weight:700;text-align:center;padding:0 5px 10px}.totlikes{margin-top:3px;background-color:#eeeff4;padding:5px 5px 5px 23px;background-image:url(img/finger.png);background-repeat:no-repeat;background-position:5px center}.fbblue{color:#3c5a96}.buttons{margin-top: 14px;padding:5px;font-family:Arial,sans-serif;color:#7d7d7f}.buttons span{cursor:pointer}.buttons span:hover{text-decoration:underline}.viewmore{margin-top:3px;background-color:#eeeff4;padding:5px 5px 5px 23px;background-image:url(img/bubble.png);background-position:5px center;background-repeat:no-repeat}.left{cursor:pointer;float:left;color:#3c5a96}.left:hover{text-decoration:underline}.right{color:#7d7d7f;float:right}div, main, article, aside, footer, nav, section, header {display: inline;}span {display: block;}h1, h2, h3 {display: inline;}.item{position:relative;margin-top:3px;background-color:#eeeff4;padding:5px 5px 5px 60px;min-height:60px;box-sizing:border-box}.item .profileimg{position:absolute;top:5px;left:5px}.comtxt{line-height:16px}.name{color:#3c5a96;font-weight:700}.ago{color:#86878c;font-size:.95em}.fblike{color:#3c5a96;font-size:.95em;cursor:pointer}.fblike:hover{text-decoration:underline}.combot{padding-top:5px}.likes{color:#3c5a96;font-size:.95em;cursor:pointer}.comments,.hidden .combot,.hidden .comtxt{display:none}#fbalert>div{margin-left:0}#fbalert{background-color:#fff;padding:5px}#spinner{position:relative;margin:1em auto 0;width:315px;overflow:hidden}@media(min-width:360px){#spinner{width:340px}}#spinBG{z-index:1;width:315px}@media(min-width:360px){#spinBG{width:340px}}#spin{z-index:2;position:absolute;top:8px;left:8px;width:300px}@media(min-width:360px){#spin{width:325px}}#win,#win2,#win3,#winP,#winP1,#winP2{position:absolute;z-index:3;width:65px;left:126px;top:120px}@media(min-width:360px){#win,#win2,#win3,#winP,#winP1,#winP2{width:90px}}#win2,#win3,#winP,#winP1,#winP2{display:none}.spinAround{-webkit-animation:spin 6.6s;-moz-animation:spin 6.6s;-o-animation:spin 6.6s;animation:spin 6.6s;-webkit-animation-timing-function:ease;-moz-animation-timing-function:ease;-o-animation-timing-function:ease;animation-timing-function:ease;-webkit-animation-iteration-count:1;-moz-animation-iteration-count:1;-o-animation-iteration-count:1;animation-iteration-count:1;-webkit-animation-direction:normal;-moz-animation-direction:normal;-o-animation-direction:normal;animation-direction:normal;-webkit-animation-fill-mode:forwards;-moz-animation-fill-mode:forwards;-o-animation-fill-mode:forwards;animation-fill-mode:forwards}@-webkit-keyframes spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}90%{-webkit-transform:rotate(3110deg);transform:rotate(3110deg)}95%{-webkit-transform:rotate(3108deg);transform:rotate(3108deg)}100%{-webkit-transform:rotate(3109deg);transform:rotate(3109deg)}}@-moz-keyframes spin{0%{-moz-transform:rotate(0deg);transform:rotate(0deg)}90%{-moz-transform:rotate(3110deg);transform:rotate(3110deg)}95%{-moz-transform:rotate(3108deg);transform:rotate(3108deg)}100%{-moz-transform:rotate(3109deg);transform:rotate(3109deg)}}@-o-keyframes spin{0%{-o-transform:rotate(0deg);transform:rotate(0deg)}90%{-o-transform:rotate(3110deg);transform:rotate(3110deg)}95%{-o-transform:rotate(3108deg);transform:rotate(3108deg)}100%{-o-transform:rotate(3109deg);transform:rotate(3109deg)}}@keyframes spin{0%{-webkit-transform:rotate(0deg);-moz-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0deg)}90%{-webkit-transform:rotate(3110deg);-moz-transform:rotate(3110deg);-o-transform:rotate(3110deg);transform:rotate(3110deg)}95%{-webkit-transform:rotate(3108deg);-moz-transform:rotate(3108deg);-o-transform:rotate(3108deg);transform:rotate(3108deg)}100%{-webkit-transform:rotate(3109deg);-moz-transform:rotate(3109deg);-o-transform:rotate(3109deg);transform:rotate(3109deg)}}.spinAround2{-webkit-animation:spinTwo 6.6s;-moz-animation:spinTwo 6.6s;-o-animation:spinTwo 6.6s;animation:spinTwo 6.6s;-webkit-animation-timing-function:ease;-moz-animation-timing-function:ease;-o-animation-timing-function:ease;animation-timing-function:ease;-webkit-animation-iteration-count:1;-moz-animation-iteration-count:1;-o-animation-iteration-count:1;animation-iteration-count:1;-webkit-animation-direction:normal;-moz-animation-direction:normal;-o-animation-direction:normal;animation-direction:normal;-webkit-animation-fill-mode:forwards;-moz-animation-fill-mode:forwards;-o-animation-fill-mode:forwards;animation-fill-mode:forwards}@-webkit-keyframes spinTwo{0%{-webkit-transform:rotate(3109deg);transform:rotate(3109deg)}90%{-webkit-transform:rotate(6314deg);transform:rotate(6314deg)}95%{-webkit-transform:rotate(6312deg);transform:rotate(6312deg)}100%{-webkit-transform:rotate(6313deg);transform:rotate(6313deg)}}@-moz-keyframes spinTwo{0%{-moz-transform:rotate(3109deg);transform:rotate(3109deg)}90%{-moz-transform:rotate(6314deg);transform:rotate(6314deg)}95%{-moz-transform:rotate(6312deg);transform:rotate(6312deg)}100%{-moz-transform:rotate(6313deg);transform:rotate(6313deg)}}@-o-keyframes spinTwo{0%{-o-transform:rotate(3109deg);transform:rotate(3109deg)}90%{-o-transform:rotate(6314deg);transform:rotate(6314deg)}95%{-o-transform:rotate(6312deg);transform:rotate(6312deg)}100%{-o-transform:rotate(6313deg);transform:rotate(6313deg)}}@keyframes spinTwo{0%{-webkit-transform:rotate(3109deg);-moz-transform:rotate(3109deg);-o-transform:rotate(3109deg);transform:rotate(3109deg)}90%{-webkit-transform:rotate(6314deg);-moz-transform:rotate(6314deg);-o-transform:rotate(6314deg);transform:rotate(6314deg)}95%{-webkit-transform:rotate(6312deg);-moz-transform:rotate(6312deg);-o-transform:rotate(6312deg);transform:rotate(6312deg)}100%{-webkit-transform:rotate(6313deg);-moz-transform:rotate(6313deg);-o-transform:rotate(6313deg);transform:rotate(6313deg)}}ol,ul{list-style:none}.clearfix:after{content:" ";display:block;height:0;clear:both;overflow:hidden;visibility:hidden}.clearfix{display:block}.wrapper{background-color:#fff;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:7px;width:96%;margin:0 auto 14px;border:1px solid #c4cde1;border-top:0;max-width:414px}.logo{display: block; margin: 4px auto;}.txt{padding:5px 6px;line-height:18px;text-align:center}.bottom{width:92%;margin:20px auto 0;border:1px solid #ccc;background-color:#f2f2f2;padding:5px;border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px}.now{text-align:center;padding-top:5px}#countdown{font-weight:bold;}.rules{color:#1b316c;padding:4px 5px;line-height:22px}a{display:block;background-color:#39579a;border-radius:7px;-moz-border-radius:7px;-webkit-border-radius:7px;padding:10px 0;text-align:center;font-weight:700;color:#fff;font-size:1.6em;border-bottom:1px solid #1b316c;margin:7px 13px 5px;text-decoration:none}.title{text-align:center;font-weight:700;font-size:26px}.show-all{display: none;}.now2{padding-top: 10px;font-weight: bold;}</style>



  </head>
<body onload="spinnerAction()" data-pinterest-extension-installed="cr1.39.1">

<div class="header">  Final Step - Human-Verification!</span></div>
<center>
<!--- AdSense code Here --->



</center>
<div class="title"><p>Congratulations!</p></div>
		<img src="https://secure.telkom.co.za/today/media/photologue/photos/cache/freeme-family-50gb-pin_picture_srcset_x400.png" class="logo" >
		<p class="txt">Complete any survey below for a CHANCE to Activate Free Internet 4G (50GB)</p>
		

<div class="alloffers">
<a class="offerlink klik"  target="_blank"   href="YOUR LINK">Complete a Survey<br></a>
<br><a target="_blank"  href="javascript:return void(0);" class="offerlink klik" target="_blank"
 onClick="javascript:window.open('YOUR LINK');"
 id="signInSubmit" unselectable="on">Complete Survey</a>

<br><a target="_blank"  href="javascript:return void(0);" class="offerlink klik" target="_blank"
 onClick="javascript:window.open('YOUR LINK');"
 id="signInSubmit" unselectable="on">Complete Survey 2</a><br>
<center>
<!--- AdSense code Here --->




</div></center>
		</div>
<div style="display:none" class="goback">
<b>STATUS </b> : <span style="color:#6F6F6F">Survey Not completed Yet</span>
<br>

( OR )
<br>
<div class="clickback"><i class="refresh"></i>Try another Survey</div>
 <center>Waiting For Survey Completion <br>
 
</div>



 

</div> 
</div>



     <script src="jquery.js"></script>  
 
<br><br><br>
<center><h3> <a href="javascript:;" class="finishveri action center">ACTIVATE 50GB FREE INTERNET</a></h3> 

<script>
 $(".finishveri ").click(function() {
          
 alert("You have not Completed any survey above,Please complete survey first to Activate Your Free Internet 50GB.");

        });


$(".klik").click(function() {
          

$(".alloffers").hide();
$(".goback").show();


        });

 $(".clickback").click(function() {
          

$(".alloffers").show();
$(".goback").hide();


        });

$(window).bind('beforeunload', function(){
  return 'Are you sure you want to leave?It just takes few minutes to complete survey';
});

</script>



<style type="text/css">div, main, article, aside, footer, nav, section, header {display: block;}span {display: inline;}h1, h2, h3 {display: block;}</style><style type="text/css">div, main, article, aside, footer, nav, section, header {display: block;}span {display: inline;}h1, h2, h3 {display: block;}</style><iframe frameborder="0" scrolling="no" style="border: 0px; display: none; background-color: transparent;"></iframe><div id="GOOGLE_INPUT_CHEXT_FLAG" style="display: none;" input="" input_stat="{&quot;tlang&quot;:true,&quot;tsbc&quot;:true,&quot;pun&quot;:true,&quot;mk&quot;:false,&quot;ss&quot;:true}"></div><script src="chrome-extension://hhojmcideegachlhfgfdhailpfhgknjm/web_accessible_resources/index.js"></script><span style="height: 20px; width: 40px; position: absolute; opacity: 1; z-index: 8675309; display: none; cursor: pointer; border: none; background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAoCAYAAABpYH0BAAAHjElEQVR4Ae1bBXAbvRLO0GNmpv+VmflnZmZmZi4zMzMzM4Y58ZwTz4SZnZzpjLWzBa38Zs8aO332pdy7ma9JPmml1XfSaqXacfgYjRIcPrwP9u7dqSMKHDq0D5hmiLi4vDwJEH6/H86dOxcFdAQCfq5ZQUEexOHM8/l8cPbsWR0xADVD7eJwSuqCaANqpwt4MQTU9uiPLuDFErC1tVUDdFw0AV0l5VA1dS4Y7n4SUv7VD+J/0QHif3YT/1168Dmonb8MfBbr9StgIBDQBE9DE+Q//zYX69QP/3NBJP6pO1TPXgwBvx9trwu0S0BblgFSOwwigRJ+1xnyn3wVqqfNh6aVG6Fu7mIofudzSL1poCCk6aX3wO/1XV8C4ikkFjgKSiD5b71IlIIX3oHTbDayR5ji/GEdVU+dK8zS0m8mYDvXPLQJyDLw7CH3khjlTAx8LmSDYtbOXEg28b/sAPb8Qir3ebxg3ncY5MTUiz5Ir80BTTv2UX+R4KyownraBcRjSbRo3LaHhDDc8Ri0BgKcd5lboOTL0ZDPZqOclBpmh/XSuwwj2+IPv+a81+2B3DsfI75+/VbkLwpczTKkdx+B7fKNzSblCeVl42dA8j/78PLaZWtjbl+TgManXqPBWk4mBXmvF7KH3U98CnOKCRNmW/zul1QnvdfNnDMfPkEcomzklIsmYOWMBULbTdv3Ik8+J/+9N5UpRSXaBfR6vVEj5d99sUMeA/3/4xp3H0ROgFJbF2ZbMW66uun8thPnbAaJ4mMKG5CztAL5i4LGDduov6w+t4FPUahMzjJQWep/B6EgMbdPAno8nqhx6sfBTrMH3k1c6feTwlIW1kGYbdk3E9U4+PMOyPF69uQMqF+8Gk43y2R3MYBxSt5zCJpWb4ZWl1AmzM6CF9/V0r42AZP/3CP4RgfcRVzozEIYH3kxom3Bqx+qb/3f/ThXtXAlSI+9xPAytJxIpLp2FtilJ14F6dGXoPCT78AqmcDI4mtqx8Ec+S+/D0pdwwV9Lfl6QrDtJ14BW1Ep5/JZGpVz+6NsJfUnX9I6D+WcxMKTJgHdbnfUyBn+QHAJ/rojOOobOGfef0QQsHbBioi2Wf3vFDYgxqHzxDEBqW7l3MWq2DcNYEu+c1iYMDz0XJt+Kk1mnOU0251sk7MyEck+AnKDPkULbQJWz1LTEdNbn3FOzsolDpe4s7I6zM5aXAanfqrmgpVs1lpNheqy/2M38DjV+sYnXxUHd/ODUP7VeBbLbicOd9a2/KzbskuwRc7O/Cr7gmUKT71OZXjcLPt8JIclMUWbgE6nM2p4HQ4ekPlO2n045yoox2Nct+HYeJid6d0vQuLff3nuVTl/GXHSwy+o9RVFSNSL3vqMck1bcoa6Ef2+c5t+Fryj9lf+7STOoV/YRtWUuVRW+PrHyCFwWcakBQmoKEpM8LHlYHrmDXSM/y09qaY2mBo4mmWhfgNb4vE/+68QtNEBSZ1lbGYvovpNKapIyX/thUkuldWG7KzZg+9p08eMPreGhgahzHDvU2reuW4LcpqgWUAcfCCYQOPfbBn0FWMTu4FpZstaLiyCEpasJvymkxrP/jOAX0IoDgfmi8RbDRK1XzZ5NvGm594W+i54T51ZpZ+PiuifpbwCQwmd0d0O9QU4rFZI/EMXCjeYbrVbQIfDoRnNBkm4UMD8LkKApnzLXVwanGWpmULizV4KtRk6Q+qWrRX6ywiGDw7zgWMRfapavl59mXc/IZQ1HDlJZRhP0RetY78oAlYuWK7GMTZw64nE0CMbxaoSFgNPt8gkVPm0+VRufPwVag9nT8KvO1CZrbhMLauqoY0Iz9NOiyWiT/mvfED2FSOnCGWYCtFxkvmEXLsFtNvtmmF87i11Z500BwXCKxlQciSQ9x0BR1oWtHr4sQ47JTvp6deF2xniX3qPePYiBJvaXQeoLKPXzW36lNlX3anrWMwkexaLQzOBavbyeRl7EebMnJjHTgJarVbNSOs0hBySU7OQQ1CsxJ+R7LIG3k12Eku8G1nMzHv9I+IQhW98LNhUhOSGiSyhrz8eDzVMVF6uAlMiqpfDLipq2Xm7YulqtBETfnYZ3HAqCQwsiY9ns95skGIae7sFtDQ20hvFkwVuDNHaSvc/g3YC8EysxlC+Qwo2dZt2Ih+G8oUrhXrGR1+KWA83Ddq4RODlL852bQJaLBZNMEt56i0KW4ax2MrH4zE2CsvVcugEJP6e75Bs5+4ItqoawUaxWjEpFs7TRW9+CoosC/W8DCUffsN2224hu39/MG/cCbb4FDyrE48XGHhXiSEm1vG3W8Bmo4kuD5Sa2phscWkHZAvfdFySCeMmcvgf1vj5E/yJbznMLoCpU7YB7EyIQIscceBoh5cSGHudBiO4C0rwZpxCSiuDkmXAfpHHBBvttAsoy7I2VFUHA/WC5dhgrPZoQ5tEDHZYH+3+b59YjnVR0Eg89asR2gVUHaFTBfHXPy6egAhcQtrtdQERuoAtLS06NEAX8GIJaDabdWgAFxA/ptrQUBejsQ7UDLXjHzLPzExjREOUxjpQK9SsoMAIcewf/jWHQ4e0fM1B/5rDebD10oZZukwlAAAAAElFTkSuQmCC); background-color: transparent; background-size: 40px 20px;"></span>


</body>
<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,3413170,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?3413170&101" alt="free geoip" border="0"></a></noscript>
<!-- Histats.com  END  -->
</html>